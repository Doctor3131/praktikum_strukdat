/* Program   : mtstack.c */
/* Deskripsi : file DRIVER modul stack karakter */
/* NIM/Nama  : */
/* Tanggal   : */
/***********************************/

#include <stdio.h>
/* include tstack+boolean */

int main() 
{	/* kamus main */
	Tstack A; // variabel A bertipe tStack
	
	/* algoritma */
	//createStack( &A );

	
	
	
	return 0;
}
